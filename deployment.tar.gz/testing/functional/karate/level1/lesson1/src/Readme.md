## This lesson is to create course dynamically 
### in this user register, login and create course
