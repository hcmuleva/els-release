// Teacher Pages - Barrel Export
export { default as TeacherContentPage } from './TeacherContentPage';
export { default as TeacherAssessmentPage } from './TeacherAssessmentPage';
export { default as QuestionBankPage } from './QuestionBankPage';
export { default as CreateQuestionPage } from './CreateQuestionPage';
export { default as ExamManagementPage } from './ExamManagementPage';
export { default as CreateExamPage } from './CreateExamPage';
