// Admin Pages - Barrel Export
export { default as AdminDashboard } from './AdminDashboard';
export { default as AdminCoursePage } from './AdminCoursePage';
export { default as AdminSubjectPage } from './AdminSubjectPage';
export { default as AdminGradePage } from './AdminGradePage';
export { default as TeacherAssignmentPage } from './TeacherAssignmentPage';
