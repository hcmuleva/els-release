// Common Pages - Barrel Export
export { default as HomePage } from './HomePage';
export { default as LoginPage } from './LoginPage';
export { default as RegisterPage } from './RegisterPage';
