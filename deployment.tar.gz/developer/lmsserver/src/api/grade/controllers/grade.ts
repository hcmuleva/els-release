/**
 * grade controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::grade.grade');
