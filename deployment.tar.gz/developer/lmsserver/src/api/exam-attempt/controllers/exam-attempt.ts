import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::exam-attempt.exam-attempt');
