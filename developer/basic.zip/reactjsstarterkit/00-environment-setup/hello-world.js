// 🎉 Your First JavaScript Program!

// This is a comment - it helps explain code but doesn't run

// console.log() prints text to the terminal
console.log("🎉 Hello, JavaScript!");
console.log("Welcome to your coding journey!");

// Let's check which version of Node.js you're using
console.log("Node.js version:", process.version);

// 🎯 EXERCISE: 
// 1. Change the message above to include your name
// 2. Add a new console.log() statement below with your favorite hobby
// 3. Run this file using: node hello-world.js

// Add your code below:
