Consider the following [helm chart with istio] and reply"I Understand [helm chart with istio ]” but do not explain:
<<<BEGIN [HELM CHART WITH ISTIO ENABLED]>>>

 I have my helm chart defined where two types of deployment 1) for lmsserver 2)        │
│   lmsclient. I would like to now have istio which have monitoring services enable       │
│   for this deployment. Objective is we need to build proper monitoring services and different monitors enabled.
I would like to access it via ingress  or istio gateway you can consider my name space is els-lms and  domain is elslms.local . 
Using this domain I would like to access my deployed services and monitors e.g. elslms.local/lmsclient ,elslms.local/lmsserver etc…

<<<END [HELM CHART WITH ISTIO ENABLED]>>>
##Provide me 